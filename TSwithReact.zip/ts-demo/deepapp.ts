

interface Address {
    street: string
    city: string
    country: string
}
interface Department {
    name: string
    floor: number
}
interface Employee {
    id: number
    name: string
    address: Address
    department: Department
}

//deeppartial
type DeepPartial<T>={
    [P in keyof T]? :T[P] extends object ? DeepPartial<T[P]> :T[P]
}
// DeepReadOnly
type DeepReadOnly<T>={
    readonly [P in keyof T]:T[P] extends object ? DeepReadOnly<T[P]> :T[P]
}
// DeepPartial

const partialUpdate:DeepPartial<Employee>={
    address:{
        city: "NY"
    },
    department:{
        name: 'HR'
    }
}
const readOnlyEmp:DeepReadOnly<Employee>={
id:902,
name: "Alice",
address:{
    street:"NY Street",
    city: 'sF',
    country:'USA'
},
department:{
    name:'Dep',
    floor:5
}
}
 