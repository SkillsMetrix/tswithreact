function demoapp(args) {
    return args;
}
var result = demoapp('welcome');
var result2 = demoapp(32);
console.log(result);
console.log(result2);
