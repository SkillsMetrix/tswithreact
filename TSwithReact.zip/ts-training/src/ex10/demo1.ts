
type Car={drive:() => void}
type Boat={sail:() => void}

type Vehicle=Car | Boat

function isBoat(v:Vehicle):v is Boat{
    return 'sail' in v
}

const myv:Vehicle={sail: () => console.log("sailing")
}