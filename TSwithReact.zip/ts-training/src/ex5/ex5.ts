
class Employee{
    constructor(public name:string){}
}
class Developer extends Employee {
    constructor(public name:string,language:string){
        super(name)
    }
}
    class Manager extends Employee {
        constructor(name:string,public teamSize:number){
            super(name)
        }
    }

    const devs: Developer[]=[
        new Developer("Alice","TS"),
        new Developer("bob","java")
    ]
    const emps:Employee[]=devs
    console.log(emps[0].name);
    