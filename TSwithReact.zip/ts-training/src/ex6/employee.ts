export interface Employee{
    name:string
    role:string
    performDuties():void
}