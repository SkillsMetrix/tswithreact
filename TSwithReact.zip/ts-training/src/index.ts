function multiply(a: number,b:number):number{

    return a*b;
}
const a=50;
const b=30;

console.log(`${a} * ${b} = ${multiply(a,b)}`);
