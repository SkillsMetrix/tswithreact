
function demoapp<T>(args: T):T {
    return args
}

const result= demoapp<string>('welcome')
const result2= demoapp(32)


console.log(result);
console.log(result2);

