
class Person{
    name: string
    constructor(name:string){
        this.name=name
    }
}
class Emp extends Person{
    empId:number
    constructor(name:string,empId:number){
        super(name)
        this.empId=empId
    }
    work(){
        console.log(`${this.name} is available`);
        
    }
}

const contractor={
    name:'BOB',
    rate:30
}
function describeWorker(worker:any){
    //typeof
    if(typeof worker === 'string'){
        console.log('worker is string');
        
    }
    //instanceof
    else if(worker instanceof Emp){
        console.log('Checked');
        
    }
    worker.work()
}
else if('hourlyrate' in worker){
    console.log();
    
}