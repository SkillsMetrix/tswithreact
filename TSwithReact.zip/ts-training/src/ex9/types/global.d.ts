
export {}

declare global{
    interface Employee{
        id: number
        name:string
        department:string
    }
}