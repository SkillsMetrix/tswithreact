

const newHire:Employee={
    id:1,
    name:"Alice",
    department:"HR"
}